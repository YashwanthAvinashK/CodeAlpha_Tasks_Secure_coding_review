import { useState, useRef } from "react";

const LANGUAGES = [
  { id: "python", label: "Python", icon: "🐍" },
  { id: "javascript", label: "JavaScript", icon: "⚡" },
  { id: "php", label: "PHP", icon: "🐘" },
  { id: "java", label: "Java", icon: "☕" },
  { id: "go", label: "Go", icon: "🔵" },
  { id: "sql", label: "SQL", icon: "🗄️" },
];

const SAMPLE_CODE = {
  python: `import sqlite3
import os
import pickle
from flask import Flask, request

app = Flask(__name__)
SECRET_KEY = "hardcoded_secret_123"
DB_PASSWORD = "admin123"

def get_user(username):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    # Direct string interpolation - dangerous!
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    cursor.execute(query)
    return cursor.fetchone()

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]
    user = get_user(username)
    if user and user[1] == password:
        return "Welcome " + username
    return "Login failed"

@app.route("/run", methods=["POST"])
def run_command():
    cmd = request.form["cmd"]
    result = os.system(cmd)  # Command injection risk!
    return str(result)

@app.route("/load", methods=["POST"])
def load_data():
    data = request.form["data"]
    obj = pickle.loads(data.encode())  # Insecure deserialization!
    return str(obj)

def log_error(error):
    print("Error: " + str(error))  # May expose sensitive data
    with open("/tmp/errors.log", "a") as f:
        f.write(str(error) + "\\n")`,

  javascript: `const express = require('express');
const fs = require('fs');
const exec = require('child_process').exec;
const jwt = require('jsonwebtoken');

const app = express();
const SECRET = "jwt_secret_key";  // Hardcoded secret

app.use(express.json());

// No rate limiting, no input validation
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  // Plaintext password comparison
  if (username === "admin" && password === "password123") {
    const token = jwt.sign({ user: username }, SECRET);
    res.json({ token });
  } else {
    res.status(401).json({ error: "Invalid credentials: " + username });
  }
});

// Path traversal vulnerability
app.get('/file', (req, res) => {
  const filename = req.query.name;
  const content = fs.readFileSync('/app/files/' + filename, 'utf8');
  res.send(content);
});

// XSS vulnerability
app.get('/greet', (req, res) => {
  const name = req.query.name;
  res.send('<h1>Hello, ' + name + '</h1>');  // Unescaped output!
});

// Command injection
app.post('/ping', (req, res) => {
  const host = req.body.host;
  exec('ping -c 1 ' + host, (err, stdout) => {
    res.send(stdout);
  });
});

app.listen(3000);
console.log("Server running on port 3000");`,

  php: `<?php
// Insecure PHP application example
$host = "localhost";
$db = "myapp";
$user = "root";
$pass = "root123";  // Hardcoded credentials

$conn = new mysqli($host, $user, $pass, $db);

// SQL Injection vulnerability
$username = $_GET['username'];
$query = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($query);

// XSS vulnerability
echo "<h1>Welcome " . $_GET['name'] . "</h1>";

// File inclusion vulnerability
$page = $_GET['page'];
include($page . ".php");  // Local/Remote File Inclusion!

// Unrestricted file upload
if ($_FILES['file']['size'] > 0) {
    $upload_dir = '/var/www/uploads/';
    $filename = $_FILES['file']['name'];  // No sanitization!
    move_uploaded_file($_FILES['file']['tmp_name'], $upload_dir . $filename);
    echo "Uploaded: " . $filename;
}

// Weak password hashing
function store_password($password) {
    return md5($password);  // MD5 is broken!
}

// Session fixation
session_start();
$_SESSION['user'] = $_POST['username'];

// Exposed sensitive info
phpinfo();  // Never in production!
?>`,

  java: `import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UserServlet extends HttpServlet {
    
    // Hardcoded credentials
    private static final String DB_URL = "jdbc:mysql://localhost/app";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "root123";
    
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        
        String username = req.getParameter("username");
        
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            
            // SQL Injection - string concatenation
            String sql = "SELECT * FROM users WHERE name = '" + username + "'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            // XSS - unescaped output
            PrintWriter out = res.getWriter();
            out.println("<html><body>Hello " + username + "</body></html>");
            
        } catch (Exception e) {
            // Leaking stack traces to client
            e.printStackTrace(res.getWriter());
        }
    }
    
    // Insecure deserialization
    public Object deserialize(byte[] data) throws Exception {
        ObjectInputStream ois = new ObjectInputStream(
            new ByteArrayInputStream(data)
        );
        return ois.readObject();  // Dangerous!
    }
    
    // XML External Entity (XXE) injection
    public void parseXML(String xml) throws Exception {
        javax.xml.parsers.DocumentBuilderFactory factory = 
            javax.xml.parsers.DocumentBuilderFactory.newInstance();
        // Missing: factory.setFeature("...", false)
        javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
    }
}`,

  go: `package main

import (
    "database/sql"
    "fmt"
    "net/http"
    "os/exec"
    "crypto/md5"
)

const dbPassword = "hardcoded_password"  // Hardcoded secret

var db *sql.DB

func getUser(w http.ResponseWriter, r *http.Request) {
    username := r.URL.Query().Get("username")
    
    // SQL Injection
    query := fmt.Sprintf("SELECT * FROM users WHERE name = '%s'", username)
    rows, err := db.Query(query)
    if err != nil {
        // Error details exposed to client
        fmt.Fprintf(w, "DB Error: %v", err)
        return
    }
    defer rows.Close()
}

func runCommand(w http.ResponseWriter, r *http.Request) {
    cmd := r.URL.Query().Get("cmd")
    // Command injection
    out, err := exec.Command("sh", "-c", cmd).Output()
    if err != nil {
        fmt.Fprintf(w, "Error: %v", err)
    }
    fmt.Fprintf(w, string(out))
}

// Weak hashing
func hashPassword(password string) string {
    return fmt.Sprintf("%x", md5.Sum([]byte(password)))
}

// Missing TLS verification
func insecureClient() *http.Client {
    return &http.Client{}
    // Should set InsecureSkipVerify but also shouldn't use it
}

func main() {
    http.HandleFunc("/user", getUser)
    http.HandleFunc("/run", runCommand)
    http.ListenAndServe(":8080", nil)  // No TLS!
}`,

  sql: `-- Insecure SQL patterns

-- Storing plaintext passwords
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100),
    password VARCHAR(100),  -- Plaintext!
    email VARCHAR(200),
    credit_card VARCHAR(20),  -- PCI violation!
    ssn VARCHAR(11)  -- PII not encrypted!
);

-- Overly permissive grants
GRANT ALL PRIVILEGES ON *.* TO 'appuser'@'%' WITH GRANT OPTION;

-- No input validation in stored procedure
CREATE PROCEDURE get_user(IN uname VARCHAR(100))
BEGIN
    SET @sql = CONCAT('SELECT * FROM users WHERE username = ''', uname, '''');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    -- Dynamic SQL without parameterization
END;

-- Weak: using MD5 for password hashing
INSERT INTO users (username, password) 
VALUES ('admin', MD5('password123'));

-- No audit logging table
-- No row-level security
-- Sensitive data without encryption at rest

-- Exposing too much in views
CREATE VIEW user_details AS
SELECT *, credit_card, ssn  -- Exposes all PII!
FROM users;

-- Missing: column encryption, data masking, audit trails`,
};

const SEVERITY_CONFIG = {
  critical: { color: "#ef4444", bg: "#fef2f2", border: "#fecaca", label: "CRITICAL", dot: "🔴" },
  high: { color: "#f97316", bg: "#fff7ed", border: "#fed7aa", label: "HIGH", dot: "🟠" },
  medium: { color: "#eab308", bg: "#fefce8", border: "#fef08a", label: "MEDIUM", dot: "🟡" },
  low: { color: "#22c55e", bg: "#f0fdf4", border: "#bbf7d0", label: "LOW", dot: "🟢" },
  info: { color: "#3b82f6", bg: "#eff6ff", border: "#bfdbfe", label: "INFO", dot: "🔵" },
};

function SeverityBadge({ severity }) {
  const cfg = SEVERITY_CONFIG[severity] || SEVERITY_CONFIG.info;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: "4px",
      padding: "2px 8px", borderRadius: "999px", fontSize: "11px",
      fontWeight: 700, letterSpacing: "0.05em",
      color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.border}`
    }}>
      {cfg.dot} {cfg.label}
    </span>
  );
}

function FindingCard({ finding, index }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = SEVERITY_CONFIG[finding.severity] || SEVERITY_CONFIG.info;
  return (
    <div style={{
      border: `1px solid ${expanded ? cfg.border : "#e5e7eb"}`,
      borderLeft: `4px solid ${cfg.color}`,
      borderRadius: "8px", marginBottom: "10px",
      background: expanded ? cfg.bg : "#fff",
      transition: "all 0.2s",
      overflow: "hidden"
    }}>
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          padding: "14px 16px", cursor: "pointer",
          display: "flex", alignItems: "center", gap: "12px"
        }}
      >
        <span style={{
          minWidth: "26px", height: "26px", borderRadius: "50%",
          background: cfg.color, color: "#fff", display: "flex",
          alignItems: "center", justifyContent: "center",
          fontSize: "12px", fontWeight: 700, flexShrink: 0
        }}>{index + 1}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
            <span style={{ fontWeight: 600, fontSize: "14px", color: "#111827" }}>{finding.title}</span>
            <SeverityBadge severity={finding.severity} />
            {finding.cwe && (
              <span style={{ fontSize: "11px", color: "#6b7280", background: "#f3f4f6", padding: "1px 6px", borderRadius: "4px" }}>
                {finding.cwe}
              </span>
            )}
          </div>
          <div style={{ fontSize: "13px", color: "#6b7280", marginTop: "2px" }}>
            Line {finding.line} · {finding.category}
          </div>
        </div>
        <span style={{ color: "#9ca3af", fontSize: "18px", flexShrink: 0 }}>{expanded ? "▲" : "▼"}</span>
      </div>
      {expanded && (
        <div style={{ padding: "0 16px 16px", borderTop: `1px solid ${cfg.border}` }}>
          <p style={{ fontSize: "14px", color: "#374151", marginTop: "12px", lineHeight: 1.6 }}>{finding.description}</p>
          {finding.snippet && (
            <div style={{ marginTop: "12px" }}>
              <div style={{ fontSize: "12px", fontWeight: 600, color: "#6b7280", marginBottom: "6px", textTransform: "uppercase", letterSpacing: "0.05em" }}>Vulnerable Code</div>
              <pre style={{
                background: "#1e1e2e", color: "#cdd6f4", padding: "12px", borderRadius: "6px",
                fontSize: "12px", overflowX: "auto", margin: 0, lineHeight: 1.5,
                borderLeft: `3px solid ${cfg.color}`
              }}>{finding.snippet}</pre>
            </div>
          )}
          {finding.fix && (
            <div style={{ marginTop: "12px" }}>
              <div style={{ fontSize: "12px", fontWeight: 600, color: "#059669", marginBottom: "6px", textTransform: "uppercase", letterSpacing: "0.05em" }}>✅ Remediation</div>
              <pre style={{
                background: "#f0fdf4", color: "#166534", padding: "12px", borderRadius: "6px",
                fontSize: "12px", overflowX: "auto", margin: 0, lineHeight: 1.5,
                border: "1px solid #bbf7d0"
              }}>{finding.fix}</pre>
            </div>
          )}
          {finding.references && (
            <div style={{ marginTop: "10px", display: "flex", gap: "8px", flexWrap: "wrap" }}>
              {finding.references.map((ref, i) => (
                <span key={i} style={{
                  fontSize: "12px", color: "#4f46e5", background: "#eef2ff",
                  padding: "2px 8px", borderRadius: "4px"
                }}>{ref}</span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ScoreGauge({ score }) {
  const color = score >= 80 ? "#22c55e" : score >= 50 ? "#eab308" : score >= 25 ? "#f97316" : "#ef4444";
  const label = score >= 80 ? "Secure" : score >= 50 ? "Moderate Risk" : score >= 25 ? "High Risk" : "Critical Risk";
  const circumference = 2 * Math.PI * 40;
  const offset = circumference - (score / 100) * circumference;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "6px" }}>
      <svg width="100" height="100" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="40" fill="none" stroke="#e5e7eb" strokeWidth="10" />
        <circle cx="50" cy="50" r="40" fill="none" stroke={color} strokeWidth="10"
          strokeDasharray={circumference} strokeDashoffset={offset}
          strokeLinecap="round" transform="rotate(-90 50 50)"
          style={{ transition: "stroke-dashoffset 1s ease" }} />
        <text x="50" y="50" textAnchor="middle" dy="0.35em" fontSize="20" fontWeight="bold" fill={color}>{score}</text>
      </svg>
      <div style={{ fontSize: "13px", fontWeight: 600, color }}>{label}</div>
    </div>
  );
}

export default function SecurityAuditTool() {
  const [selectedLang, setSelectedLang] = useState("python");
  const [code, setCode] = useState(SAMPLE_CODE["python"]);
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("findings");
  const abortRef = useRef(null);

  const handleLangSelect = (lang) => {
    setSelectedLang(lang);
    setCode(SAMPLE_CODE[lang] || "");
    setReport(null);
    setError(null);
  };

  const runAudit = async () => {
    if (!code.trim()) return;
    setLoading(true);
    setReport(null);
    setError(null);

    const controller = new AbortController();
    abortRef.current = controller;

    const systemPrompt = `You are an elite application security engineer performing a thorough code review. Analyze the provided code and return a JSON security audit report.

Return ONLY valid JSON — no markdown, no backticks, no preamble.

JSON structure:
{
  "language": "string",
  "summary": "2-3 sentence executive summary of overall security posture",
  "score": number (0-100, where 100 = perfectly secure, 0 = critically insecure),
  "findings": [
    {
      "id": "VULN-001",
      "title": "short title",
      "severity": "critical|high|medium|low|info",
      "category": "Injection|XSS|Auth|Crypto|Config|Access Control|Deserialization|etc",
      "cwe": "CWE-89",
      "line": "approximate line number or range",
      "description": "clear explanation of the vulnerability and risk",
      "snippet": "the vulnerable code snippet (2-4 lines)",
      "fix": "corrected/safe version of the code (2-6 lines)",
      "references": ["OWASP A03:2021", "CWE-89"]
    }
  ],
  "bestPractices": [
    { "title": "short title", "description": "actionable recommendation" }
  ],
  "owaspMapping": {
    "A01:2021": number_of_findings,
    "A02:2021": number_of_findings,
    "A03:2021": number_of_findings,
    "A05:2021": number_of_findings,
    "A06:2021": number_of_findings,
    "A08:2021": number_of_findings,
    "A09:2021": number_of_findings
  }
}

Be thorough: identify SQL injection, XSS, command injection, hardcoded secrets, weak crypto, insecure deserialization, path traversal, missing auth, sensitive data exposure, XXE, SSRF, and any language-specific issues.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal: controller.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          system: systemPrompt,
          messages: [{
            role: "user",
            content: `Audit this ${selectedLang.toUpperCase()} code:\n\n${code}`
          }]
        })
      });

      const data = await res.json();
      const text = data.content?.map(b => b.text || "").join("") || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setReport(parsed);
      setActiveTab("findings");
    } catch (err) {
      if (err.name !== "AbortError") {
        setError("Audit failed. Check your connection and try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  const severityCounts = report?.findings?.reduce((acc, f) => {
    acc[f.severity] = (acc[f.severity] || 0) + 1;
    return acc;
  }, {}) || {};

  const OWASP_LABELS = {
    "A01:2021": "Broken Access Control",
    "A02:2021": "Crypto Failures",
    "A03:2021": "Injection",
    "A05:2021": "Security Misconfiguration",
    "A06:2021": "Vulnerable Components",
    "A08:2021": "Insecure Deserialization",
    "A09:2021": "Logging Failures"
  };

  return (
    <div style={{
      minHeight: "100vh", background: "#0f0f1a",
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      color: "#e2e8f0"
    }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
        borderBottom: "1px solid #1e3a5f",
        padding: "20px 24px"
      }}>
        <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "4px" }}>
            <div style={{
              width: "36px", height: "36px", borderRadius: "8px",
              background: "linear-gradient(135deg, #4f46e5, #7c3aed)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "18px"
            }}>🛡️</div>
            <div>
              <h1 style={{ margin: 0, fontSize: "20px", fontWeight: 700, color: "#f1f5f9" }}>
                SecureAudit
              </h1>
              <div style={{ fontSize: "12px", color: "#64748b" }}>AI-Powered Code Security Scanner</div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "24px" }}>
        {/* Language selector */}
        <div style={{ marginBottom: "20px" }}>
          <div style={{ fontSize: "12px", fontWeight: 600, color: "#64748b", marginBottom: "10px", textTransform: "uppercase", letterSpacing: "0.1em" }}>
            Select Language
          </div>
          <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
            {LANGUAGES.map(lang => (
              <button
                key={lang.id}
                onClick={() => handleLangSelect(lang.id)}
                style={{
                  padding: "8px 16px", borderRadius: "8px", border: "1px solid",
                  cursor: "pointer", fontSize: "13px", fontWeight: 600,
                  transition: "all 0.15s",
                  borderColor: selectedLang === lang.id ? "#4f46e5" : "#1e293b",
                  background: selectedLang === lang.id
                    ? "linear-gradient(135deg, #4f46e5, #7c3aed)"
                    : "#1e293b",
                  color: selectedLang === lang.id ? "#fff" : "#94a3b8"
                }}
              >
                {lang.icon} {lang.label}
              </button>
            ))}
          </div>
        </div>

        {/* Code editor */}
        <div style={{ marginBottom: "16px" }}>
          <div style={{ fontSize: "12px", fontWeight: 600, color: "#64748b", marginBottom: "8px", textTransform: "uppercase", letterSpacing: "0.1em" }}>
            Code to Audit
          </div>
          <textarea
            value={code}
            onChange={e => setCode(e.target.value)}
            style={{
              width: "100%", minHeight: "280px", padding: "16px",
              background: "#1e1e2e", color: "#cdd6f4", border: "1px solid #1e3a5f",
              borderRadius: "10px", fontSize: "12.5px", fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
              lineHeight: 1.6, resize: "vertical", boxSizing: "border-box",
              outline: "none"
            }}
            placeholder="Paste your code here..."
            spellCheck={false}
          />
        </div>

        {/* Scan button */}
        <button
          onClick={runAudit}
          disabled={loading || !code.trim()}
          style={{
            padding: "12px 32px", borderRadius: "10px", border: "none",
            cursor: loading ? "not-allowed" : "pointer", fontSize: "14px", fontWeight: 700,
            background: loading ? "#374151" : "linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)",
            color: loading ? "#6b7280" : "#fff",
            display: "flex", alignItems: "center", gap: "8px",
            transition: "all 0.2s", marginBottom: "28px",
            boxShadow: loading ? "none" : "0 4px 20px rgba(79,70,229,0.4)"
          }}
        >
          {loading ? (
            <>
              <span style={{
                width: "14px", height: "14px", border: "2px solid #6b7280",
                borderTopColor: "#9ca3af", borderRadius: "50%",
                display: "inline-block", animation: "spin 0.8s linear infinite"
              }} />
              Analyzing vulnerabilities...
            </>
          ) : "🔍 Run Security Audit"}
        </button>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>

        {error && (
          <div style={{
            padding: "14px 16px", borderRadius: "8px", marginBottom: "20px",
            background: "#fef2f2", border: "1px solid #fecaca", color: "#dc2626", fontSize: "14px"
          }}>⚠️ {error}</div>
        )}

        {/* Results */}
        {report && (
          <div>
            {/* Score + Summary */}
            <div style={{
              background: "#1e293b", border: "1px solid #1e3a5f", borderRadius: "12px",
              padding: "24px", marginBottom: "20px",
              display: "flex", gap: "28px", alignItems: "flex-start", flexWrap: "wrap"
            }}>
              <ScoreGauge score={report.score} />
              <div style={{ flex: 1, minWidth: "200px" }}>
                <div style={{ fontSize: "11px", fontWeight: 700, color: "#64748b", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: "6px" }}>
                  Security Posture — {report.language?.toUpperCase()}
                </div>
                <p style={{ fontSize: "14px", color: "#cbd5e1", lineHeight: 1.7, margin: "0 0 16px" }}>{report.summary}</p>
                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                  {Object.entries(severityCounts).map(([sev, count]) => {
                    const cfg = SEVERITY_CONFIG[sev];
                    if (!cfg) return null;
                    return (
                      <div key={sev} style={{
                        padding: "6px 12px", borderRadius: "8px",
                        background: cfg.bg, border: `1px solid ${cfg.border}`,
                        display: "flex", alignItems: "center", gap: "6px"
                      }}>
                        <span style={{ fontSize: "14px" }}>{cfg.dot}</span>
                        <span style={{ fontSize: "13px", fontWeight: 700, color: cfg.color }}>{count}</span>
                        <span style={{ fontSize: "11px", color: cfg.color, fontWeight: 500 }}>{cfg.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div style={{ display: "flex", gap: "4px", marginBottom: "16px", background: "#1e293b", padding: "4px", borderRadius: "10px", width: "fit-content" }}>
              {[
                { id: "findings", label: `🔴 Findings (${report.findings?.length || 0})` },
                { id: "owasp", label: "🗂 OWASP Mapping" },
                { id: "practices", label: "✅ Best Practices" }
              ].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
                  padding: "8px 16px", borderRadius: "7px", border: "none",
                  cursor: "pointer", fontSize: "13px", fontWeight: 600,
                  background: activeTab === tab.id ? "#4f46e5" : "transparent",
                  color: activeTab === tab.id ? "#fff" : "#64748b",
                  transition: "all 0.15s"
                }}>{tab.label}</button>
              ))}
            </div>

            {/* Findings tab */}
            {activeTab === "findings" && (
              <div>
                {report.findings?.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "40px", color: "#22c55e", fontSize: "16px" }}>
                    ✅ No vulnerabilities detected!
                  </div>
                ) : (
                  report.findings?.map((f, i) => <FindingCard key={f.id || i} finding={f} index={i} />)
                )}
              </div>
            )}

            {/* OWASP tab */}
            {activeTab === "owasp" && (
              <div style={{ background: "#1e293b", border: "1px solid #1e3a5f", borderRadius: "12px", padding: "20px" }}>
                <div style={{ fontSize: "13px", fontWeight: 700, color: "#94a3b8", marginBottom: "16px", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  OWASP Top 10 Coverage
                </div>
                {Object.entries(report.owaspMapping || {}).map(([key, count]) => (
                  <div key={key} style={{ marginBottom: "12px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                      <span style={{ fontSize: "13px", color: "#cbd5e1", fontWeight: 600 }}>
                        {key} · {OWASP_LABELS[key] || key}
                      </span>
                      <span style={{ fontSize: "13px", color: count > 0 ? "#f97316" : "#22c55e", fontWeight: 700 }}>
                        {count} {count === 1 ? "finding" : "findings"}
                      </span>
                    </div>
                    <div style={{ height: "6px", background: "#0f172a", borderRadius: "3px", overflow: "hidden" }}>
                      <div style={{
                        height: "100%", borderRadius: "3px",
                        width: `${Math.min(100, count * 20)}%`,
                        background: count > 2 ? "#ef4444" : count > 0 ? "#f97316" : "#22c55e",
                        transition: "width 0.8s ease"
                      }} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Best Practices tab */}
            {activeTab === "practices" && (
              <div style={{ display: "grid", gap: "12px", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))" }}>
                {report.bestPractices?.map((bp, i) => (
                  <div key={i} style={{
                    background: "#1e293b", border: "1px solid #1e3a5f", borderRadius: "10px", padding: "16px"
                  }}>
                    <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
                      <span style={{
                        minWidth: "28px", height: "28px", background: "#064e3b",
                        borderRadius: "6px", display: "flex", alignItems: "center",
                        justifyContent: "center", fontSize: "14px"
                      }}>✓</span>
                      <div>
                        <div style={{ fontSize: "13px", fontWeight: 700, color: "#f1f5f9", marginBottom: "4px" }}>{bp.title}</div>
                        <div style={{ fontSize: "12.5px", color: "#94a3b8", lineHeight: 1.6 }}>{bp.description}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Empty state */}
        {!report && !loading && (
          <div style={{
            textAlign: "center", padding: "48px 24px",
            background: "#1e293b", border: "1px dashed #1e3a5f", borderRadius: "12px"
          }}>
            <div style={{ fontSize: "40px", marginBottom: "12px" }}>🛡️</div>
            <div style={{ fontSize: "16px", fontWeight: 600, color: "#94a3b8", marginBottom: "6px" }}>
              Ready to scan
            </div>
            <div style={{ fontSize: "13px", color: "#475569" }}>
              Select a language, review or edit the sample code, then click Run Security Audit.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
