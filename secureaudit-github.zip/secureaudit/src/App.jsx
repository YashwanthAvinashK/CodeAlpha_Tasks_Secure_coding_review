import SecurityAuditTool from './SecurityAuditTool'
export default function App() {
  return <SecurityAuditTool />
}
